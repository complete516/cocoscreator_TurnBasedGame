# -*- coding: utf-8 -*-
import os
import sys
import time
from src.ReadXlsFile import ReadXlsFile


reload(sys)
sys.setdefaultencoding('utf-8')

def isXlsFile(xlsFile):
    if os.path.isdir(xlsFile):
        return True
    return False

def getXlsFilexlsxFileList(xlsFile):
    xlsFileList = []
    fileList =  os.listdir(xlsFile)
    for key in range(0,len(fileList)):
        xlsName = fileList[key]
        if xlsName.find('$') == -1 and xlsName.find(".xlsx") != -1:
            xlsFileList.append(xlsName)
    return xlsFileList

def main():
    print(u"当前路径 ["+os.path.abspath(u"../..")+u"]")
    # abspath = os.path.abspath(u"..")
    abspath = os.path.abspath(u"../..")
    # xlsRootFile = os.path.join(abspath,"xls")
    xlsRootFile = abspath
    if isXlsFile(xlsRootFile):
        rxf = ReadXlsFile(abspath,xlsRootFile)
        xlsFileList = getXlsFilexlsxFileList(xlsRootFile)
        print(u"待处理的xls列表:")
        strContext = "[\n  "
        for key in range(len(xlsFileList)):
            strContext+=xlsFileList[key]+(( key >0 and key%3==0)and"\n  "or", ")
        # print(xlsFileList)
        print (strContext+'\n]\n'); 

        if len(xlsFileList) >0:
            for key in range(0,len(xlsFileList)):
                xlsFile = xlsFileList[key]
                rxf.readXlsxFile(xlsFile)
        else:
            print('no "xlsx" file to ' + xlsRootFile)
    else:
        print('no "xls" file to '+abspath)
    

if __name__ == "__main__":
    os.system("cls")
    print(u'-----------------------------')
    print(u'将要操作的表格放在本程序目录的xls目录下')
    print(u'程序自动遍历xls目录下.xlsx文件')
    print(u'在本程序目录的结构下会生成json文件夹')
    print(u'文件中存放对应的.json文件')
    # print(u'lua 表的key 默认以xlsx文件的index字段为key')
    print(u"   按任意键进行下一步操作    ")
    print(u'-----------------------------')
    raw_input()
    main()
    # raw_input()